<?php
session_start();
require_once '../models/Auth.php';

if (!empty($_POST['email'])){
    $reg = new Auth();
    $user = $reg -> Login($_POST['email'], $_POST['password']);
    if ($user){
        $_SESSION['user'] = $user;
        header('Location: ../index.php');
    } else {
        $_SESSION['user'] = 'incorrect';
        header('Location: ../login.php');
    }
}