<?php
session_start();
if(!empty($_SESSION['student'])){
    header('Location:../../students/student-card.php');
}
