<?php
session_start();
require_once '../models/Auth.php';


if (!empty($_POST['email'])){
    $reg = new Auth();
    $user = $reg -> Registration($_POST['login'], $_POST['password'], $_POST['email']);
    if ($user){
        $_SESSION['user'] = $user;
        header('Location: ../index.php');
    } else {
        $_SESSION['user'] = 'exist';
        header('Location: ../views/register/register.php');
    }
}

