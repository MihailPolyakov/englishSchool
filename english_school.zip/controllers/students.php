<?php
require_once '../models/students.php';

class Students
{
    public function getStudents($id_teacher){
        $get_students = new StudentsModel();
        $get_students = $get_students->getTeacherStudents($id_teacher);
        if ($get_students){
            return $get_students;
        } else {
            return false;
        }
    }
}