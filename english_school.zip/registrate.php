<?php
session_start();
if(!empty($_SESSION['user'])){
    header('Location:index.php');
}?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="views/bootstrap4/css/bootstrap.min.css">
    <title>Войти</title>
</head>
<body>
<div class="container h-100">
    <div class="row h-100 justify-content-center align-items-center">
        <form class="col-sm-4 col-md-4 col-lg-4" action="controllers/registrate.php" method="POST">
            <div class="form-group">
                <label for="login">Имя пользователя</label>
                <input type="text" class="form-control" id="login" name="login" placeholder="Введите ваше имя">
            </div>
            <div class="form-group">
                <label for="mail">Email</label>
                <input type="email" class="form-control" id="mail" name="email" placeholder="Введите ваш email">
            </div>
            <?php
            if (!empty($_SESSION['user']) && $_SESSION['user'] == 'exist'){
                session_destroy();?>
                <span class="text-danger">Такой email уже существует</span>
            <?php } ?>
            <div class="form-group">
                <label for="pass">Пароль</label>
                <input type="text" class="form-control" id="pass" name="password" placeholder="Введите пароль">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Зарегестрироваться</button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
