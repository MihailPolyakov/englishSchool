<?php
session_start();
if (empty($_SESSION['student']) || empty($_SESSION['user'])){
    header("HTTP/1.0 404 Not Found");
}
require_once '../models/ConnectDb.php';
require_once '../models/student-card/studentCard.php';
$student = new studentCard($_SESSION['user'][0]['id'], $_SESSION['student']);
if(!$student){
    header("HTTP/1.0 404 Not Found");
}
?>
<!doctype html>
<html lang="RU">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../views/bootstrap4/css/bootstrap.min.css">
    <title>Студент <?php echo $student->portfolio['login']?></title>
</head>
<body>
    <?php require_once '../views/header/header.php' ?>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                Портфолио
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="?lp=lp">
                                План урока
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                Расписание
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                Оплата
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            <?php


            if(!empty($_POST['add-topic'])){
                $student->addTopic($_POST['add-topic']);
                header('Location:student-card.php?lp=lp');
            }

            if(!empty($_GET['lp'])){
                require_once '../views/student-card/lessonTable.php';
            }

            if (!empty($_GET['topicId'])){
                require_once '../views/student-card/topic-date.php';
            }

            if(!empty($_GET['hw'])){
                require_once '../views/student-card/homework.php';
            }

            if (!empty($_POST['homework-edit'])){
                $student->updateHomework($id_topic, $_POST['homework-edit'], (int)$_POST['id']);
                header("Location:student-card.php?hw=$id_topic");
            }

            if (!empty($_POST['new-homework'])){
                $student->addHomework($id_topic, $_POST['new-homework']);
                header("Location:student-card.php?hw=$id_topic");
            }



            if(!empty($_FILES)){
                $student->addFilesHomeWork($_FILES, $id_topic);
            }
            ?>
        </div>
    </div>
</body>

</html>
