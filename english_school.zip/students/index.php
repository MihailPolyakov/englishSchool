<?php
session_start();
if (empty($_SESSION['user']) || $_SESSION['user'][0]['status'] != 'teacher'){
    header("HTTP/1.0 404 Not Found");
}
?>
<!doctype html>
<html lang="RU">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../views/bootstrap4/css/bootstrap.min.css">
    <title>Мои студенты</title>
</head>
<body>
    <?php require_once '../views/header/header.php';
          require_once '../controllers/students.php';
        $students = new Students();
        $getStudents = $students->getStudents($_SESSION['user'][0]['id']);
        if (!empty($getStudents)){?>
            <div class="container">
                <div class="row flex-md-row align-items-center">
                    <?php
                    foreach ($getStudents as $student){
                        ?>
                        <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                            <div>
                                <h2><a href="?student=<?php echo $student['id']?>"><?php echo $student['login']?></a></h2>
                            </div>
                            <div>
                                <span>Уровень <?php echo $student['level']?></span>
                            </div>
                            <div>
                                <span>Возраст <?php echo $student['age']?></span>
                            </div>
                        </div>

                    <?php  }?>
                </div>
            </div>
  <?php } ?>
</body>
</html>
<?php
if (!empty($_GET['student'])){
    $_SESSION['student'] = $_GET['student'];
    header('Location: ../controllers/student-card/student-card.php');
}

