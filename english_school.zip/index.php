<?php
session_start();?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="views/bootstrap4/css/bootstrap.min.css">
    <title>Home</title>
</head>
<body>
<?php
if (!empty($_SESSION['user'])){
    require_once 'views/homepage-student';
 } else {?>
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
        <h5 class="my-0 mr-md-auto font-weight-normal">Company name</h5>
        <a class="btn btn-outline-primary mx-2" href="login.php">Войти</a>
        <a class="btn btn-outline-primary mx-2" href="registrate.php">Зарегестрироваться</a>
    </div>
<?php } ?>
</body>

</html>
