<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Слова по теме <?php echo $_GET['topic']?></h1>
    </div>
    <form action="" class="form-inline" method="POST">
        <input style="max-width: 300px;" type="text" class="form-control mb-2 mr-sm-2" name="english-word" placeholder="Введите слово">
        <input type="submit" class="btn btn-primary mb-2" value="Искать">
    </form>
    <?php if (!empty($_POST['english-word'])){
        $result = $student->searchWord($_POST['english-word']);
        if($result):?>
        <form action="" method="POST">
            <table class="table table-bordered" style="width: 50%">
                <tr>
                    <th><?php echo $result['english']?></th>
                    <th><?php echo $result['russian']?></th>
                    <th>
                        <input type="hidden" name="id_word" value="<?php echo $result['id']?>">
                        <input type="hidden" name="id_topic" value="<?php echo $_GET['dic']?>">
                        <input class="btn btn-primary mb-2" type="submit" class="btn btn-primary mb-2" value="Добавить слово в словарь">
                    </th>
                </tr>
            </table>
        </form>
        <?php else:?>
            <h4>К сожалению этого слова пока еще нет в словаре, но вы можете внести слово и перевод в поле ниже</h4>
            <form action="" method="POST">
                <table class="table table-bordered" style="width: 50%">
                    <tr>
                        <th><input type="text" name="english" value="<?php echo $_POST['english-word']?>" placeholder="Английское слово"></th>
                        <th><input type="text" name="russian" placeholder="Перевод"></th>
                        <th>
                            <input type="hidden" name="id_topic" value="<?php echo $_GET['dic']?>">
                            <input class="btn btn-primary mb-2" type="submit" class="btn btn-primary mb-2" value="Добавить слово в словарь">
                        </th>
                    </tr>
                </table>
            </form>
        <?php endif;
    }
    if(!empty($_POST['id_word']) && !empty($_POST['id_topic'])){
        $student->addWordToDic($_POST['id_word'], $_POST['id_topic']);
    }
    if(!empty($_POST['english']) && !empty($_POST['russian'])){
        $student->addWord($_POST['id_topic'], $_POST['english'], $_POST['russian']);
    }?>
    <table class="table table-bordered table-hover">
        <thead class="thead-dark">
        <tr>
            <th>English</th>
            <th>Русский</th>
        </tr>
        </thead>
        <tbody>
        <?php
        foreach ($student->getWords($_GET['dic']) as $value){?>
            <tr>
                <th><div style="min-height: 50px;"><span><?php echo $value['english']?></span></div></th>
                <th><div style="min-height: 50px;"><span><?php echo $value['russian']?></span></div></th>
           </tr>
        <?php }?>
        </tbody>
    </table>
</main>