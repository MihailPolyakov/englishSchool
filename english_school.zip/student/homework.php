<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Домашние задание по теме <?php echo $_GET['topic']?></h1>
    </div>
    <table class="table table-bordered table-hover">
        <thead class="thead-dark">
        <tr>
            <th>#</th>
            <th>Домашние задание</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $count = 1;
        foreach ($student->getHomework($_GET['hw']) as $value){?>
            <tr>
                <th><?php echo $count++?></th>
                <th><div style="min-height: 150px;"><span><?php echo $value['homework']?></span></div></th>
            </tr>
        <?php }?>
        </tbody>
    </table>
</main>