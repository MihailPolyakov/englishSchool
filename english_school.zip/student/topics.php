<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Домашние задания</h1>
    </div>
    <table class="table table-bordered table-hover">
        <thead class="thead-dark">
        <tr>
            <th>#</th>
            <th>Тема</th>
            <th>Домашние задание</th>
            <th>Слова</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $count = 1;
        foreach ($student->getTopics() as $value){?>
            <tr>
                <th><?php echo $count++?></th>
                <th><div style="min-height: 150px;"><span><?php echo $value['topic']?></span></div></th>
                <th><a href="?hw=<?php echo $value['id']?>&topic=<?php echo $value['topic']?>">Посмотреть домашнее задание</a></th>
                <th><a href="?dic=<?php echo $value['id']?>&topic=<?php echo $value['topic']?>">Посмотреть слова</a></th>
            </tr>
        <?php }?>
        </tbody>
    </table>
</main>