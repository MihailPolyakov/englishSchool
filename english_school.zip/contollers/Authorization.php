<?php
require_once '../models/Auth.php';

class Authorization {

    public function Registration($login, $password, $email){
        $reg = new Auth();
        if ($reg -> Registration($login, $password, $email)){
            
        }
    }
}