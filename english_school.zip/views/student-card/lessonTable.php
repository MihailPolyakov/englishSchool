<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">План урока</h1>
    </div>
    <table class="table table-bordered table-hover">
        <thead class="thead-dark">
        <tr>
            <th>Тема</th>
            <th>ДЗ</th>
            <th>Словарь</th>
        </tr>
        </thead>
        <tbody>
            <?php
            foreach ($student->getLessonTable() as $value){?>
            <tr>
                <th><a href="?topicId=<?php echo $value['id']?>&topicName=<?php echo $value['topic']?>"><?php echo $value['topic']?></a></th>
                <th><a href="?hw=<?php echo $value['id']?>">Изменить</a></th>
                <th><a href="?dic=<?php echo $value['id']?>">Изменить</a></th>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    <form action="" method="POST">
        <input type="text" name="add-topic">
        <input type="submit" value="Добавить тему">
    </form>
</main>
