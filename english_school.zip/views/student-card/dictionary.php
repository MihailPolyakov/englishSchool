<?php $id_topic = $_GET['dic'];
if (!empty($_POST['english-word']) && !empty($_POST['russian-word'])){
    $student->addWord($id_topic, $_POST['english-word'], $_POST['russian-word']);
    header("Location:student-card.php?dic=$id_topic");
}

if (!empty($_POST['word-en-edit']) && !empty($_POST['word-ru-edit'])){
    $student->updateWord($id_topic, $_POST['word-en-edit'], $_POST['word-ru-edit'], $_POST['id']);
    header("Location:student-card.php?dic=$id_topic");
}

if(!empty($_GET['delete-word'])){
    $student->deleteWord($id_topic, $_GET['delete-word'], $_GET['id']);
    header("Location:student-card.php?dic=$id_topic");
}?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Словарь</h1>
    </div>
    <form action="" method="POST">
        <input type="text" name="english-word">
        <input type="text" name="russian-word">
        <input type="submit" value="Добавить в словарь">
    </form>
    <?php

    if(!empty($_GET['edit-word'])){?>

    <form action="" method="POST">
        <?php } ?>
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
            <tr>
                <th>English</th>
                <th>Русский</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($student->getWords($id_topic) as $value){?>
                <tr>
                    <?php if (!empty($_GET['edit-word']) && $value['id'] == $_GET['edit-word']):?>
                        <th>
                            <input type="hidden" name="id" value="<?php echo $value['id']?>">
                            <input type="text" style="min-height: 50px; width: 100%" name="word-en-edit" value="<?php echo $value['english']?>">
                        </th>
                        <th>
                            <input type="text" style="min-height: 50px; width: 100%" name="word-ru-edit" value="<?php echo $value['russian']?>">
                        </th>
                        <th><input type="submit" value="Выполнить изменения"><a href="?delete-word=<?php echo $value['id']?>&dic=<?php echo $id_topic?>&topic=<?php echo $id_topic?>">Удалить</a></th>
                    <?php else:?>
                        <th><div style="min-height: 50px;"><span><?php echo $value['english']?></span></div></th>
                        <th><div style="min-height: 50px;"><span><?php echo $value['russian']?></span></div></th>
                        <th><a href="?dic=<?php echo $id_topic?>&edit-word=<?php echo $value['id']?>">Изменить</a><a style="margin-left: 40px;" href="?delete-word=<?php echo $value['id']?>&dic=<?php echo $id_topic?>&id=<?php echo $value['id_cross']?>">Удалить</a></th>
                    <?php endif;?>
                </tr>
            <?php }?>
            </tbody>
        </table>
        <?php
        if(!empty($_GET['edit-word'])){?>
    </form>
<?php } ?>
</main>