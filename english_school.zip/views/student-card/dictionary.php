<?php $id_topic = $_GET['dic']?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Словарь</h1>
    </div>
    <?php
    if (!empty($_GET['delete'])){
        $student->deleteHomework($id_topic, (int)$_GET['delete']);
    }
    if(!empty($_GET['edit'])){?>
    <form action="" method="POST">
        <?php } ?>
        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
            <tr>
                <th>English</th>
                <th>Русский</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $count = 1;
            foreach ($student->getHomework($id_topic) as $value){?>
                <tr>
                    <?php if (!empty($_GET['edit']) && $value['id'] == $_GET['edit']):?>
                        <th><?php echo $count++?></th>
                        <th>
                            <input type="hidden" name="id" value="<?php echo $value['id']?>">
                            <input type="text" style="min-height: 150px; width: 100%" name="homework-edit" value="<?php echo $value['homework']?>">
                        </th>
                        <th><input type="submit" value="Выполнить изменения"><a href="?delete=<?php echo $value['id']?>">Удалить</a></th>
                    <?php else:?>
                        <th><?php echo $count++?></th>
                        <th><div style="min-height: 150px;"><span><?php echo $value['homework']?></span></div></th>
                        <th><a href="?hw=<?php echo $id_topic?>&edit=<?php echo $value['id']?>">Изменить</a><a style="margin-left: 40px;"href="?delete=<?php echo $value['id']?>">Удалить</a></th>
                    <?php endif;?>
                </tr>
            <?php }?>
            </tbody>
        </table>
        <?php
        if(!empty($_GET['edit'])){?>
    </form>
<?php } ?>
    <form action="" method="POST" ENCTYPE="multipart/form-data">
        <input type="file" name="data[]" multiple>
        <input type="text" name="new-homework">
        <input type="submit" value="Добавить ДЗ">
    </form>
</main>