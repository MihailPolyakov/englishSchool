<?php $id_topic = $_GET['hw'];?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h1 class="h2">Домашние задания</h1>
    </div>
    <form action="" method="POST">
    <table class="table table-bordered table-hover">
        <thead class="thead-dark">
        <tr>
            <th>#</th>
            <th>Домашние задание</th>
        </tr>
        </thead>
        <tbody>
            <?php
            $count = 1;
            foreach ($student->getHomework($id_topic) as $value){?>
                <tr>
                    <th><?php echo $count++?></th>
                    <th><input type="text" name="hw<?php echo $value['id']?>" value="<?php echo $value['homework']?>"></th>
                </tr>
            <?php } ?>

        </tbody>
    </table>
    <input type="submit" value="Обновить домашнее задание">
    </form>
    <form action="" method="POST">
        <input type="text" name="new-homework">
        <input type="submit" value="Добавить ДЗ">
    </form>
</main>

