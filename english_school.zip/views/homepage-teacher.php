<div class="container">
    <div class="row text-center">
        <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
            <div class="text-center">
                <h3><a href="./students">Ученики</a></h3>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
            <div class="text-center">
                <h3><a href="./schedule">Расписание</a></h3>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
            <div class="text-center">
                <h3><a href="./payment">Оплаты</a></h3>
            </div>
        </div>
    </div>
</div>
