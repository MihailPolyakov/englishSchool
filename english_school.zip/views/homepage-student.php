<?php
require_once 'models/ConnectDb.php';
require_once 'models/student-card/studentBoard.php';
$student = new studentBoard($_SESSION['user'][0]['id']);
?>
<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="?link=homework">
                            Домашнее задание
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?link=dictionary">
                            Словарь
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?link=shedule">
                            Расписание
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <?php if(!empty($_GET['link']) && $_GET['link'] = 'homework'){
            require_once 'student/topics.php';
        }
        if (!empty($_GET['hw'])){
            require_once 'student/homework.php';
        }
        if (!empty($_GET['dic'])){
            require_once 'student/dictionary.php';
        }
        ?>

    </div>
</div>