function editHW(id_homework) {
    document.getElementById(id_homework.match(/\d+/)[0]).style.display = 'none';

}