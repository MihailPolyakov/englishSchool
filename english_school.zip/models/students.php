<?php
require_once 'connectDB.php';
class StudentsModel {
    private $pdo;
    public function __construct()
    {
        $this->pdo = new ConnectDb();
        $this->pdo = $this->pdo->dbConnect();

    }

    public function getTeacherStudents($id_teacher){
        $id_teacher = (int)$id_teacher;
        $query = "SELECT login, description, age, level, id FROM users WHERE users.teacher = $id_teacher";
        $query = $this->pdo->prepare($query);
        if ($query->execute()){
            return $query->fetchAll(PDO::FETCH_ASSOC);
        } else {
            return false;
        }
    }
}