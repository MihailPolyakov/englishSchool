<?php
require_once 'connectDB.php';
class Students {

    private function __construct($id_teacher)
    {
        $pdo = new ConnectDb();
        $pdo = $pdo->dbConnect();
        $query = "SELECT name, description, age, level FROM users WHERE users.id_teacher = $id_teacher";
        $query = $pdo->prepare($query);
        if ($query->execute()){
            return $query->fetchAll(PDO::FETCH_ASSOC);
        } else {
            return false;
        }
    }
}