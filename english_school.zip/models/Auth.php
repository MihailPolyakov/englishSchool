<?php

require_once 'ConnectDb.php';
class Auth {

    public function Registration($login, $password, $email){
        $pdo = new ConnectDb;
        $check_email = $pdo->dbConnect()->prepare("SELECT email FROM `users` WHERE `email` = '$email'");
        $check_email->execute();
        $check_email = $check_email->fetch();
        if (empty($check_email)){
            $insert = $pdo->dbConnect()->prepare("INSERT INTO `users` SET `login` = :login, `password` = :password, `email` = :email");
            $password = md5($password);
            return $insert->execute(array('login' => $login, 'password' => $password, 'email' => $email));
        } else {
            return false;
        }
    }

    public function Login($email, $password){
        $pdo = new ConnectDb;
        $password = md5($password);
        $check_email = $pdo->dbConnect()->prepare("SELECT login, id FROM `users` WHERE `email` = '$email' AND `password` = '$password'");
        $check_email->execute();
        $check_email = $check_email->fetchAll(PDO::FETCH_ASSOC);
        if (empty($check_email)){
            return false;
        } else {
            return $check_email;
        }
    }
}

