<?php

class ConnectDb {
    protected $login = 'root';
    protected $password = '';
    protected $db = 'englishSchool';
    public function dbConnect(){
        return new PDO("mysql:dbname=$this->db;host=localhost", $this->login, $this->password);
    }
}