<?php

require_once 'connectDB.php';
class Dictionary
{
    private $pdo = NULL;
    private $id_user = NULL;
    private $id_topic = NULL;

    public function __construct($topic_id, $user_id)
    {
        $pdo = new ConnectDb();
        $this->pdo = $pdo->dbConnect();
        $this->id_user = $user_id;
        $this->id_topic = $topic_id;
    }

    public function addWord()
    {
        $query = "INSERT INTO `dictionary` (`id`, `english`, `russian`) VALUES ";
        foreach ()
        $prepare = $this->pdo->prepare("INSERT INTO `dictionary` SET `english` = :english, `russian` = :russian");

        foreach ()
        $prepare->execute();
    }
}