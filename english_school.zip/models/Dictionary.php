<?php

require_once 'connectDB.php';
class Dictionary
{
    private $pdo = NULL;
    private $id_user = NULL;
    private $id_topic = NULL;

    public function __construct($topic_id, $user_id)
    {
        $pdo = new ConnectDb();
        $this->pdo = $pdo->dbConnect();
        $this->id_user = $user_id;
        $this->id_topic = $topic_id;
    }

    public function addWord($array_words)
    {

        $query = "INSERT INTO `dictionary` (`english`, `russian`) VALUES ";
        $count_array = count($array_words)/2;
        for ($i = 1; $i <= $count_array; $i++){
            $en = "en$i";
            $ru = "ru$i";
            if ($i == $count_array){
                $query .= "('$array_words[$en]', '$array_words[$ru]')";
            } else {
                $query .= "('$array_words[$en]', '$array_words[$ru]'), ";
            }
        }
        $prepare = $this->pdo->prepare($query);
        $prepare->execute();
    }
}

$array = ['en1' => 'test', 'ru1' => 'тест','en2' => 'test', 'ru2' => 'тест','en3' => 'test', 'ru3' => 'тест'];
$test = new Dictionary(1, 2);
$test -> addWord($array);