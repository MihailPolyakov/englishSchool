<?php


class studentBoard
{
    private $id_student;
    private $pdo;
    public $portfolio;
    public function __construct($id_student)
    {
        $this->id_student = $id_student;
        $this->pdo = new ConnectDb();
        $this->pdo = $this->pdo->dbConnect();
    }

    public function getTopics()
    {
        $topics = $this->pdo->prepare("SELECT topic.id, topic.topic FROM `topic` JOIN cross_table ON cross_table.id_topic = topic.id WHERE cross_table.id_user = $this->id_student AND cross_table.id_dictionary IS NULL");
        $topics->execute();
        return $topics->fetchAll(PDO::FETCH_ASSOC);
    }

        public function getHomework($id_topic)
    {
        $homeworkData = $this->pdo->prepare("SELECT homework, id FROM `homework` WHERE id_user = $this->id_student AND id_topic = $id_topic");
        $homeworkData->execute();
        return $homeworkData->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getWords($id_topic){
        $dictionary = $this->pdo->prepare("SELECT dictionary.id, dictionary.english, dictionary.russian, cross_table.id as id_cross FROM `dictionary` JOIN cross_table ON cross_table.id_dictionary = dictionary.id WHERE cross_table.id_user = $this->id_student AND cross_table.id_topic = $id_topic");
        $dictionary->execute();
        return $dictionary->fetchAll(PDO::FETCH_ASSOC);
    }

    public function searchWord($englishWord)
    {
        $search = $this->pdo->prepare("SELECT id, english, russian FROM `dictionary` WHERE english = '$englishWord'");
        $search->execute();
        $result = $search->fetchAll(PDO::FETCH_ASSOC);
        if ($result){
            return $result[0];
        } else {
            return false;
        }
    }

    public function addWordToDic($id_word, $id_topic)
    {
        $insert = $this->pdo->prepare("INSERT INTO `cross_table` SET `id_user` = :id_user, `id_dictionary` = :id_dictionary, `id_topic` = :id_topic");
        $insert->execute(array('id_user' => $this->id_student, 'id_dictionary' => $id_word, 'id_topic' => $id_topic));
    }

    public function addWord($id_topic, $english, $russian){
        $insertWord = $this->pdo->prepare("INSERT INTO `dictionary` SET `english` = :english, `russian` = :russian");
        $insertWord = $insertWord->execute(array('english' => $english, 'russian' => $russian));
        if($insertWord){
            $idWord = (int)$this->pdo->lastInsertId();
        } else {
            return false;
        }
        $insertCrossTable = $this->pdo->prepare("INSERT INTO `cross_table` SET `id_user` = :id_user, `id_topic` = :id_topic, `id_dictionary` = :id_dictionary");
        $insertCrossTable->execute(array('id_user' => $this->id_student, 'id_topic' => $id_topic, 'id_dictionary' => $idWord));
    }
}