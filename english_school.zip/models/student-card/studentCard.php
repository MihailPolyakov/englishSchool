<?php


class studentCard
{
    private $id_teacher;
    private $id_student;
    private $pdo;
    public $portfolio;

    public function __construct($id_teacher, $id_student)
    {
        $this->id_student = $id_student;
        $this->id_teacher = $id_teacher;
        $this->pdo = new ConnectDb();
        $this->pdo = $this->pdo->dbConnect();
        $check_student = $this->pdo->prepare("SELECT login, age, description, level FROM `users` WHERE `teacher` = $this->id_teacher AND `id` = $this->id_student");
        $check_student->execute();
        $check_student = $check_student->fetchAll(PDO::FETCH_ASSOC);
        if(!$check_student){
            return false;
        } else {
            $this->portfolio = $check_student[0];
        }
    }

    public function getLessonTable()
    {
        $topics = $this->pdo->prepare("SELECT topic.id, topic.topic FROM `topic` JOIN cross_table ON cross_table.id_topic = topic.id WHERE cross_table.id_user = $this->id_student");
        $topics->execute();
        return $topics->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addTopic($name_topic)
    {
        $checkTopic = $this->pdo->prepare("SELECT id FROM `topic` WHERE topic = '$name_topic'");
        $checkTopic->execute();
        $checkTopic = $checkTopic->fetchAll(PDO::FETCH_ASSOC);
        if(empty($checkTopic)){
            $insertTopic = $this->pdo->prepare("INSERT INTO `topic` SET `topic` = :topic");
            $insertTopic = $insertTopic->execute(array('topic' => $name_topic));
            if($insertTopic){
                $idTopic = (int)$this->pdo->lastInsertId();
            } else {
                return false;
            }
        } else {
            $idTopic = $checkTopic[0]['id'];
        }
        $insertCrossTable = $this->pdo->prepare("INSERT INTO `cross_table` SET `id_user` = :id_user, `id_topic` = :id_topic");
        $insertCrossTable = $insertCrossTable->execute(array('id_user' => $this->id_student, 'id_topic' => $idTopic));
        if($insertCrossTable){
            return true;
        } else {
            return false;
        }
    }
    
    public function getDateTopic($id_topic)
    {
        $checkTopic = $this->pdo->prepare("SELECT id, date FROM calendar WHERE id_teacher = $this->id_teacher AND id_student = $this->id_student AND id_topic = $id_topic");
        $checkTopic->execute();
        return $checkTopic->fetchAll(PDO::FETCH_ASSOC);
    }

    public function homeWork($id_topic)
    {
        $checkTopic = $this->pdo->prepare("SELECT id FROM `topic` WHERE ");
        $checkTopic->execute();
        $checkTopic = $checkTopic->fetchAll(PDO::FETCH_ASSOC);
    }
}