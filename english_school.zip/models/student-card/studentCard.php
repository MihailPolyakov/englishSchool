<?php


class studentCard
{
    private $id_teacher;
    private $id_student;
    private $pdo;
    public $portfolio;

    public function __construct($id_teacher, $id_student)
    {
        $this->id_student = $id_student;
        $this->id_teacher = $id_teacher;
        $this->pdo = new ConnectDb();
        $this->pdo = $this->pdo->dbConnect();
        $check_student = $this->pdo->prepare("SELECT login, age, description, level FROM `users` WHERE `teacher` = $this->id_teacher AND `id` = $this->id_student");
        $check_student->execute();
        $check_student = $check_student->fetchAll(PDO::FETCH_ASSOC);
        if(!$check_student){
            return false;
        } else {
            $this->portfolio = $check_student[0];
        }
    }

    public function getLessonTable()
    {
        $topics = $this->pdo->prepare("SELECT topic.id, topic.topic FROM `topic` JOIN cross_table ON cross_table.id_topic = topic.id WHERE cross_table.id_user = $this->id_student");
        $topics->execute();
        return $topics->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addTopic($name_topic)
    {
        $checkTopic = $this->pdo->prepare("SELECT id FROM `topic` WHERE topic = '$name_topic'");
        $checkTopic->execute();
        $checkTopic = $checkTopic->fetchAll(PDO::FETCH_ASSOC);
        if(empty($checkTopic)){
            $insertTopic = $this->pdo->prepare("INSERT INTO `topic` SET `topic` = :topic");
            $insertTopic = $insertTopic->execute(array('topic' => $name_topic));
            if($insertTopic){
                $idTopic = (int)$this->pdo->lastInsertId();
            } else {
                return false;
            }
        } else {
            $idTopic = $checkTopic[0]['id'];
        }
        $insertCrossTable = $this->pdo->prepare("INSERT INTO `cross_table` SET `id_user` = :id_user, `id_topic` = :id_topic");
        $insertCrossTable = $insertCrossTable->execute(array('id_user' => $this->id_student, 'id_topic' => $idTopic));
        if($insertCrossTable){
            return true;
        } else {
            return false;
        }
    }
    
    public function getDateTopic($id_topic)
    {
        $checkTopic = $this->pdo->prepare("SELECT id, date FROM calendar WHERE id_teacher = $this->id_teacher AND id_student = $this->id_student AND id_topic = $id_topic");
        $checkTopic->execute();
        return $checkTopic->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getHomework($id_topic)
    {
        $homeworkData = $this->pdo->prepare("SELECT homework, id FROM `homework` WHERE id_user = $this->id_student AND id_topic = $id_topic");
        $homeworkData->execute();
        return $homeworkData->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addHomework($id_topic, $homework)
    {
        $insert = $this->pdo->prepare("INSERT INTO `homework` SET `homework` = :homework, `id_user` = :id_user, `id_topic` = :id_topic");
        $insert->execute(array('homework' => $homework, 'id_user' => $this->id_student, 'id_topic' => $id_topic));
    }

    public function addFilesHomeWork($array_files, $id_topic)
    {
        $student_dir = "../files-hw/$this->id_student";
        $topic_dir = $student_dir . "/$id_topic";
        if (!file_exists($student_dir)){
            mkdir($student_dir);
        }
        if (!file_exists($topic_dir)){
            mkdir($topic_dir);
        }
        for ($i=0; $i < count($array_files['data']['name']); $i++){
            move_uploaded_file($array_files['data']['tmp_name'][$i], $topic_dir . "/" . $array_files['data']['name'][$i]);
        }
    }

    public function updateHomework($id_topic, $homework, $id_homework){
        $insert = $this->pdo->prepare("UPDATE `homework` SET `homework` = :homework WHERE `id_user` = :id_user AND `id_topic` = :id_topic AND `id` = :id_homework");
        $insert->execute(array('homework' => $homework, 'id_user' => $this->id_student, 'id_topic' => $id_topic, 'id_homework' => $id_homework));
    }
}