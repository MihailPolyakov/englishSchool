<?php
$login = 'root';
$password = '';
try {
    $pdo = new PDO('mysql:dbname=englishschool;host=localhost', $login, $password);
} catch (PDOException $e) {
    die($e->getMessage());
}

$tables =
    [
        'CREATE TABLE IF NOT EXISTS dictionary (
        id  INTEGER PRIMARY KEY,
        english TEXT NOT NULL,
        russian TEXT NULL
      )',

        'CREATE TABLE IF NOT EXISTS topic (
        id  INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        date_create TIMESTAMP NOT NULL
      )',

        'CREATE TABLE IF NOT EXISTS cross_table (
        id  INTEGER PRIMARY KEY,
        id_user int NOT NULL,
        id_dictionary int NOT NULL,
        id_topic int NOT NULL
      )',

        'CREATE TABLE IF NOT EXISTS users (
        id  INTEGER PRIMARY KEY,
        login VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        status VARCHAR(255) NOT NULL,
        key_session VARCHAR(255) NULL,
        date_create TIMESTAMP NOT NULL  
      )'
    ];
foreach ($tables as $command) {
    var_dump($pdo->exec($command));
}

