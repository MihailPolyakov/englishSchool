<?php
$login = 'root';
$password = '';
try {
    $pdo = new PDO('mysql:dbname=englishschool;host=localhost', $login, $password);
} catch (PDOException $e) {
    die($e->getMessage());
}

$tables =
    [
        "CREATE TABLE IF NOT EXISTS dictionary (
        id  INTEGER PRIMARY KEY AUTO_INCREMENT,
        english TEXT NOT NULL,
        russian TEXT NULL
      )",

        "CREATE TABLE IF NOT EXISTS links (
        id  INTEGER PRIMARY KEY AUTO_INCREMENT,
        name TEXT NULL
      )",

        "CREATE TABLE IF NOT EXISTS calendar (
        id  INTEGER PRIMARY KEY AUTO_INCREMENT,
        date_any DATE NOT NULL
      )",

        "CREATE TABLE IF NOT EXISTS homework (
        id  INTEGER PRIMARY KEY AUTO_INCREMENT,
        homework TEXT NOT NULL
      )",

        "CREATE TABLE IF NOT EXISTS topic (
        id  INTEGER PRIMARY KEY AUTO_INCREMENT,
        topic TEXT NOT NULL,
        date_create TIMESTAMP NOT NULL
      )",

        "CREATE TABLE IF NOT EXISTS cross_table (
        id  INTEGER PRIMARY KEY AUTO_INCREMENT,
        id_user int NULL,
        id_dictionary int NULL,
        id_topic int NULL,
        id_calendar int NULL,
        id_homework int NULL,
        id_links int NULL
      )",

        "CREATE TABLE IF NOT EXISTS users (
        id  INTEGER PRIMARY KEY AUTO_INCREMENT,
        login VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        age int NULL,
        description TEXT NULL,
        level TEXT NULL,
        status VARCHAR(255) NOT NULL DEFAULT 'student',
        teacher int NULL, 
        key_session VARCHAR(255) NULL,
        date_create TIMESTAMP NOT NULL  
      )"
    ];
foreach ($tables as $command) {
    var_dump($pdo->exec($command));
}

